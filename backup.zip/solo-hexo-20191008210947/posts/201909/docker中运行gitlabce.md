title: docker中运行gitlab-ce
date: '2019-09-12 16:27:17'
updated: '2019-09-12 16:31:27'
tags: [docker, gitlab]
permalink: /articles/2019/09/12/1568276837239.html
---
#### 拉取gitlab镜像
```
docker pull docker.io/gitlab/gitlab-ce
```
#### 创建本地映射目录
```
mkdir -p /home/gitlab/config
mkdir -p /home/gitlab/logs
mkdir -p /home/gitlab/data
```
#### 启动容器
```
docker run --name gitlab -p 4443:443 -p 8888:80 -p 2333:23 -v /home/gitlab/config:/etc/gitlab -v /home/gitlab/logs:/var/log/gitlab -v /home/gitlab/data:/var/opt/gitlab docker.io/gitlab/gitlab-ce
```
在1G内存的ECS中无法运行起来，终止！
